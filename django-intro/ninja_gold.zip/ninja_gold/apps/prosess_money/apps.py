from django.apps import AppConfig


class ProsessMoneyConfig(AppConfig):
    name = 'prosess_money'
